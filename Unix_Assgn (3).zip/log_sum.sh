#!/bin/bash

# place the blacklist and log file under the same directory of bash file.

# Declaring Variables

files=${!#}
argcount=$#
val=($*)
flag=0
if [[ $files != "-" ]] && [[ $files != "thttpd.log" ]]; then
f1=$(cat thttpd.log)
if ! [ -z "$f1" ]; then
filename="thttpd.log"
val+=("$filename")
argcount=$(( argcount + 1 ))
else
echo "File does not exist"
exit 0;
fi
elif [[ $files = "-" ]]; then
    f1=$(cat "thttpd.log")
    if ! [ -z "$f1" ]; then
    filename="thttpd.log"
    val[${#val[@]}-1]=$filename
    else
    echo "File does not exist"
    exit 0;
    fi
else 
    filename=${val[${#val[@]}-1]}
fi

len=${#val[@]}

params=(-c -2 -r -F -t)
optn=(-n)
# Declaring Functions
# cleaning for common result
function preCleaningforResult(){
   # Below Awk is used for summing and ordered the data in decreasing order of each status codes.
   local getting=$(awk '$9 >= 200 && $9 <= 500 {print $9, $1}' "$filename" | sort -nr | uniq -c | sort -rn | sort -nrk1,1 |awk '{ if (data[$2] eq 0 && $2 eq $2)} {data[$2]=data[$2]+$1} END { for(var in data) { print var, "\t\t", data[var]}}' | sort -nrk2 | awk 'BEGIN { ORS=" " }{ print $1 }') 
   dat1=( "$getting" ) # (Storing and Reordering the Status codes in decreasing order)
   local fgh=$(awk '$9 >= 200 && $9 <= 500 {print $9, $1}' "$filename" | sort -nr | uniq -c | sort -rn | sort -nrk1,1 | awk '{ print $2 "\t" $3 }') # (sorting the Data according to the highest count)
   for a in $dat1
   do
   local arch=$(echo "$fgh" | awk -v n="$a" '{if($1 == n) print  }')
   echo "${arch}" >> "data.txt"
   done
   preCleaningr=$(cat data.txt)
   rm data.txt
}

# cleaning for Failures
function preCleaningforFailures(){
   local gett=$(awk '$9 >= 400 && $9 <= 500 {print $9, $1}' "$filename" | sort -nr | uniq -c | sort -rn | sort -nrk1,1 |awk '{ if (data[$2] eq 0 && $2 eq $2)} {data[$2]=data[$2]+$1} END { for(var in data) { print var, "\t\t", data[var]}}' | sort -nrk2 | awk 'BEGIN { ORS=" " }{ print $1 }')
   dat2=( "$gett" )
   local fgh=$(awk '$9 >= 400 && $9 <= 500 {print $9, $1}' "$filename"| sort -nr | uniq -c | sort -rn | sort -nrk1,1 | awk '{ print $2 "\t" $3 }') 
   for a in $dat2
   do
   local arch=$(echo "$fgh" | awk -v n="$a" '{if($1 == n) print}')
   echo "${arch}" >> "data.txt"
   done
   preCleaningf=$(cat data.txt)
   rm data.txt
}
# Blacklisting Function
# Please wait for few minutes if requested for full search of the data.( log_sum.sh (-c|-2|-r|-F|-t) [-e] <filename> )
function blacklist(){
if [[ $data =~ ^[0-9]+$ ]] && [ $flag -eq 0 ]; then
echo "$blacking" | head -n "$data" > c.txt
elif [ $flag -eq 1 ]; then
echo "$blacking" > c.txt
else
echo "$blacking" > c.txt
fi
val=$(awk '{print $1}' c.txt | awk 'BEGIN { ORS=" " }{ print $1 }')
stored=( "$val" )
for a in $stored
do
# Below function is used to remove full stops at the end of the domain name and empty spaces present in the output.
c="$(nslookup "$a" | grep "name =" | cut -d " " -f 3 | sed -r 's/.$//' | grep -Ev "^$")"
if  [ "$c" != "" ]; then
    b=$(grep "$c" blacklistv2.txt)
    if [ "$b" != "" ]; then
        echo "Blacklisted!" >> ce.txt
    else
        echo " " >> ce.txt
  fi
else 
     echo " "  >> ce.txt
fi
done
paste c.txt ce.txt > fce.txt
blisted=$(cat fce.txt)
rm c.txt ce.txt fce.txt
}

# most number of request connection attempts
function highestRequestsCounting(){
    echo "Please wait for few seconds to minutes if you used an extension -e"
    printf "\tIP\t\tRequests \n"
    highc=$(awk '{ print $1 }' "$filename" | sort -nr | uniq -c | sort -nr | awk '{print $2 "\t\t" $1}')
    if [[ ${params[*]} =~ ${val[$len/2 - 1]} ]] && [ $argcount != 4 ] && [ $argcount != 5 ] && [ $argcount != 3 ]; then 
    echo "$highc"
    elif [ $argcount -eq 3 ] && [[ ${params[*]} =~ ${val[$len/2 - 1]} ]]; then
    blacking="$highc"
    blacklist
    echo "$blisted" | awk '{ print $1 "\t\t" $2,$3 }'
    elif [[ ${val[$len - 2]} =~ ^[0-9]+$ ]]; then
    local data=${val[$len - 2]}
    echo "$highc" | head -n "$data"
    elif [[ ${val[$len - 4]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    blacking="$highc"
    data=${val[$len - 4]}
    blacklist
    echo "$blisted" | awk '{ print $1 "\t\t" $2,$3 }' | awk 'NR <='+"$data"
    elif [[ ${val[$len - 3]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    blacking="$highc"
    data=${val[$len - 3]}
    blacklist
    echo "$blisted" | awk '{ print $1 "\t\t" $2,$3}' | awk 'NR <='+"$data"
    else
    local data=${val[$len/2 - 1]}
    echo "$highc" | head -n "$data"
    fi
}

# most successful attempts
function successfulAttempts(){
   echo "Please wait for few seconds to minutes if you used an extension -e"
   printf "\tIP\t\tSuccessfulAttempts\n"
   successatt=$(awk '$9 >= 200 && $9 < 400 {print $1,$9}' "$filename" | awk '{ print $1 }' | sort -nr | uniq -c | sort -nr | awk '{print $2 "\t\t" $1}')
    if [[ ${params[*]} =~ ${val[$len/2 - 1]} ]] && [ $argcount != 4 ] && [ $argcount != 5 ] && [ $argcount != 3 ]; then 
    echo "$successatt"
    elif [ $argcount -eq 3 ] && [[ ${params[*]} =~ ${val[$len/2 - 1]} ]]; then
    blacking="$successatt"
    blacklist
    echo "$blisted" | awk '{ print $1 "\t\t" $2,$3 }' 
    elif [[ ${val[$len - 2]} =~ ^[0-9]+$ ]]; then
    local data=${val[$len - 2]}
    echo "$successatt" | head -n "$data"
    elif [[ ${val[$len - 4]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    blacking="$successatt"
    data=${val[$len - 4]}
    blacklist
    echo "$blisted" | awk '{ print $1 "\t\t" $2,$3 }' | awk 'NR <='+"$data"
    elif [[ ${val[$len - 3]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    blacking="$successatt"
    data=${val[$len - 3]}
    blacklist
    echo "$blisted" | awk '{ print $1 "\t\t" $2,$3 }' | awk 'NR <='+"$data"
    else
    local data=${val[$len/2 - 1]}
    echo "$successatt" | head -n "$data"
    fi
}

# most unsuccessful attempts
function unsuccessfulAttempts(){
   echo "Please wait for few seconds to minutes if you used an extension -e"
    printf "Status\t\tIP\n"
    preCleaningforFailures
    if [[ ${params[*]} =~ ${val[$len/2 - 1]} ]] && [ $argcount != 4 ] && [ $argcount != 5 ] && [ $argcount != 3 ]; then 
    for a in $dat2
    do
    local comFailures=$(echo "$preCleaningf" |awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $1 "\t" $2 }')
    echo "$comFailures"
    printf "\n\n"
    done
    elif [ $argcount -eq 3 ] && [[ ${params[*]} =~ ${val[$len/2 - 1]} ]]; then
    blacking=$(echo "$preCleaningf" | awk '{ print $2 "\t" $1 }')
    blacklist
    for a in $dat2
    do
    echo "$blisted" | awk -v n="$a"  '{if($2 == n) print}' | awk '{ print $2 "\t" $1,$3 }'
    printf "\n\n"
    done
    elif [[ ${val[$len - 2]} =~ ^[0-9]+$ ]]; then
    local data=${val[$len - 2]}
    for a in $dat2
    do
    local comFailures=$(echo "$preCleaningf" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $1 "\t" $2 }' | awk 'NR <='+"$data")
    echo "$comFailures"
    printf "\n\n"
    done
    elif [[ ${val[$len - 4]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    data=${val[$len - 4]}
    for a in $dat2
    do
    local comFailures=$( echo "$preCleaningf" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $2 "\t" $1 }' | awk 'NR <='+"$data")
    echo "$comFailures" >> black.txt
    done
    blacking=$(cat black.txt)
    flag=1
    blacklist
    for a in $dat2
    do
    echo "$blisted" | awk -v n="$a"  '{if($2 == n) print}' | awk '{ print $2 "\t" $1,$3 }' | awk 'NR <='+"$data"
    printf "\n\n"
    done
    rm black.txt
    elif [[ ${val[$len - 3]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    data=${val[$len - 3]}
    for a in $dat2
    do
    local comFailures=$(echo "$preCleaningf" |awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $2 "\t" $1 }' | awk 'NR <='+"$data" )
    echo "$comFailures" >> black.txt
    done
    blacking=$(cat black.txt)
    flag=1
    blacklist
    for a in $dat2
    do
    echo "$blisted" | awk -v n="$a"  '{if($2 == n) print}' | awk '{ print $2 "\t" $1,$3 }' | awk 'NR <='+"$data"
    printf "\n\n"
    done
    rm black.txt
    else
    local data=${val[$len/2 - 1]}
    for a in $dat2
    do
    local comFailures=$(echo "$preCleaningf" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $1 "\t" $2 }' | awk 'NR <='+"$data")
    echo "$comFailures"
    printf "\n\n"
    done
    fi
}

# common result
function commonResultCode(){
    echo "Please wait for few seconds to minutes if you used an extension -e"
    printf "Status\t\tIP\n"
    preCleaningforResult
    if [[ ${params[*]} =~ ${val[$len/2 - 1]} ]] && [ $argcount != 4 ] && [ $argcount != 5 ] && [ $argcount != 3 ]; then 
    for a in $dat1
    do
    local comresult=$(echo "$preCleaningr" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $1 "\t" $2 }')
    echo "$comresult"
    printf "\n\n"
    done
    elif [ $argcount -eq 3 ] && [[ ${params[*]} =~ ${val[$len/2 - 1]} ]]; then
    blacking=$(echo "$preCleaningr" | awk '{print $2 "\t" $1}')
    blacklist
    for a in $dat1
    do
    echo "$blisted" | awk -v n="$a"  '{if($2 == n) print}' | awk '{ print $2 "\t" $1,$3 }'
    printf "\n\n"
    done
    elif [[ ${val[$len - 2]} =~ ^[0-9]+$ ]]; then
    local data=${val[$len - 2]}
    for a in $dat1
    do
    local comresult=$(echo "$preCleaningr" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $1 "\t" $2 }' | awk 'NR <='+"$data")
    echo "$comresult"
    printf "\n\n"
    done
    elif [[ ${val[$len - 4]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    data=${val[$len - 4]}
    for a in $dat1
    do
    local comresult=$(echo "$preCleaningr" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $2 "\t" $1 }' | awk 'NR <='+"$data")
    echo "$comresult" >> black.txt
    done
    blacking=$(cat black.txt)
    flag=1
    blacklist
    for a in $dat1
    do
    echo "$blisted" | awk -v n="$a"  '{if($2 == n) print}' | awk '{ print $2 "\t" $1,$3 }' | awk 'NR <='+"$data"
    printf "\n\n"
    done
    rm black.txt
    elif [[ ${val[$len - 3]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
    data=${val[$len - 3]}
    for a in $dat1
    do
    local comresult=$(echo "$preCleaningr" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $2 "\t" $1 }' | awk 'NR <='+"$data") 
    echo "$comresult" >> black.txt
    done
    blacking=$(cat black.txt)
    flag=1
    blacklist
    for a in $dat1
    do
    echo "$blisted" | awk -v n="$a"  '{if($2 == n) print}' | awk '{ print $2 "\t" $1,$3 }' | awk 'NR <='+"$data"
    printf "\n\n"
    done
    rm black.txt
    else
    local data=${val[$len/2 - 1]}
    for a in $dat1
    do
    local comresult=$(echo "$preCleaningr" | awk -v n="$a"  '{if($1 == n) print}' | awk '{ print $1 "\t" $2 }' | awk 'NR <='+"$data")
    echo "$comresult"
    printf "\n\n"
    done
    fi
}

# Total Bytes sent
function totalBytes(){
   echo "Please wait for few seconds to minutes if you used an extension -e"
   printf "\tIP\tBytes\n"
   totbytes=$(awk '{if ($10 !="-")print $10, $1}' "$filename" | sort -rn | awk '{ if (data[$2] eq 0 && $2 eq $2)} {data[$2]=data[$2]+$1} END { for(var in data) { print var, "\t\t", data[var]}}' | sort -nrk 2 | awk '{print $1 "\t" $2}')
   if [[ ${params[*]} =~ ${val[$len/2 - 1]} ]] && [ $argcount != 4 ] && [ $argcount != 5 ] && [ $argcount != 3 ]; then
   echo "$totbytes"
   elif [ $argcount -eq 3 ] && [[ ${params[*]} =~ ${val[$len/2 - 1]} ]]; then
   blacking="$totbytes"
   blacklist
   echo "$blisted" | awk '{ print $1 "\t" $2,$3 }'
   elif [[ ${val[$len - 2]} =~ ^[0-9]+$ ]]; then
   local data=${val[$len - 2]}
   echo "$totbytes" | head -n "$data"
   elif [[ ${val[$len - 4]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
   blacking="$totbytes"
   data=${val[$len - 4]}
   blacklist
   echo "$blisted" | awk '{ print $1 "\t" $2,$3 }' | awk 'NR <='+"$data"
   elif [[ ${val[$len - 3]} =~ ^[0-9]+$ ]] && [ $argcount -eq 5 ]; then
   blacking="$totbytes"
   data=${val[$len - 3]}
   blacklist
   echo "$blisted" | awk '{ print $1 "\t" $2,$3 }' | awk 'NR <='+"$data"
   else
   local data=${val[$len/2 - 1]}
   echo "$totbytes" | head -n "$data"
   fi
}

# Switching
function switching(){
   case "$condition" in
        -c) highestRequestsCounting
        ;;
        -2) successfulAttempts 
        ;; 
        -r) commonResultCode
        ;;
        -F) unsuccessfulAttempts 
        ;;
        -t) totalBytes
        ;;
         *) echo "Invalid Operation Authorized" 
        ;;
      esac
}

# Main Driver Code
if [ $argcount -ge 2 ] &&  [ -r "$filename" ] && [[ "${params[*]}" =~ ${val[$len -2]} ]] && ! [[ ${val[$len -2]} =~ ^[0-9]+$ ]]; then
   if ! [[ "${params[*]}" =~ ${val[0]} ]] && [ $argcount != 4 ] || [[ ${val[0]} =~ ^[0-9]+$ ]];  
      then echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
      -n: Limit the number of results to N
      -c: Which IP address makes the most number of connection attempts?
      -2: Which address makes the most number of successful attempts?
      -r: What are the most common results codes and where do they come
      from?
      -F: What are the most common result codes that indicate failure (no
      auth, not found etc) and where do they come from?
      -t: Which IP number get the most bytes sent to them?
      <filename> refers to the logfile.
      "
   else
   # log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename> || log_sum.sh (-c|-2|-r|-F|-t) <filename>
      if [ $argcount = 4 ]; then
         case $1 in
            -n)condition=${val[ $len - 2 ]}
                 switching
                 ;;
            *) echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
            -n: Limit the number of results to N
            -c: Which IP address makes the most number of connection attempts?
            -2: Which address makes the most number of successful attempts?
            -r: What are the most common results codes and where do they come
            from?
            -F: What are the most common result codes that indicate failure (no
            auth, not found etc) and where do they come from?
            -t: Which IP number get the most bytes sent to them?
            <filename> refers to the logfile.
            "
         esac
      else
      condition=${val[ $len - 2 ]}
      switching
      fi
   fi
elif [ $argcount -ge 2 ] && [ -r "$filename" ] && [[ ${val[2]} =~ ^[0-9]+$ ]]; then
     if [[ ${optn[*]} =~ ${val[1]} ]] && [[ ${params[*]} =~ ${val[0]} ]] && [ $argcount -eq 4 ]; then
     # log_sum.sh (-c|-2|-r|-F|-t) [-n N] <filename>
     case ${val[$len - 3]} in
         -n) condition=${val[0]}
          switching
         ;;
      *) echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
      -n: Limit the number of results to N
      -c: Which IP address makes the most number of connection attempts?
      -2: Which address makes the most number of successful attempts?
      -r: What are the most common results codes and where do they come
      from?
      -F: What are the most common result codes that indicate failure (no
      auth, not found etc) and where do they come from?
      -t: Which IP number get the most bytes sent to them?
      <filename> refers to the logfile.
      "
      ;;
      esac
     elif [ $argcount -eq 5 ] && [ -r "$filename" ] &&  [[ ${val[2]} =~ ^[0-9]+$ ]] && [[ ${val[1]} = ${optn[0]} ]]; then
     # log_sum.sh (-c|-2|-r|-F|-t) [-n N] [-e] <filename>
         case ${val[$len - 2]} in
         -e) condition=${val[0]}
         switching
         ;;
         *) echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
         -n: Limit the number of results to N
         -c: Which IP address makes the most number of connection attempts?
         -2: Which address makes the most number of successful attempts?
         -r: What are the most common results codes and where do they come
         from?
         -F: What are the most common result codes that indicate failure (no
         auth, not found etc) and where do they come from?
         -t: Which IP number get the most bytes sent to them?
         <filename> refers to the logfile.
         "
    esac
     else
          echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
          -n: Limit the number of results to N
          -c: Which IP address makes the most number of connection attempts?
          -2: Which address makes the most number of successful attempts?
          -r: What are the most common results codes and where do they come
           from?
          -F: What are the most common result codes that indicate failure (no
          auth, not found etc) and where do they come from?
          -t: Which IP number get the most bytes sent to them?
          <filename> refers to the logfile.
          "
     fi
   elif [ $argcount -eq 5 ] && [ -r "$filename" ] &&  [[ ${val[1]}  =~ ^[0-9]+$ ]] && [[ ${val[0]} = ${optn[0]} ]]; then
   # log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
    case ${val[$len - 2]} in
         -e) condition=${val[$len/2]}
         switching
         ;;
         *) echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
         -n: Limit the number of results to N
         -c: Which IP address makes the most number of connection attempts?
         -2: Which address makes the most number of successful attempts?
         -r: What are the most common results codes and where do they come
         from?
         -F: What are the most common result codes that indicate failure (no
         auth, not found etc) and where do they come from?
         -t: Which IP number get the most bytes sent to them?
         <filename> refers to the logfile.
         "
    esac
   elif [ $argcount -eq 3 ] && [ -r "$filename" ]; then
   # log_sum.sh (-c|-2|-r|-F|-t) [-e] <filename>
   # Please wait for the data to be collected as it takes more time for searching and matching with the balcklist file.
    case ${val[$len - 2]} in
         -e) condition=${val[0]}
         echo "Requesting to Search for the Blacklisting on the whole data might take few minutes. Please wait we are processing the data."
         switching
         ;;
         *) echo "Please specify your command in this specified format: log_sum.sh (-c|-2|-r|-F|-t) [-e] <filename>
         -n: Limit the number of results to N
         -c: Which IP address makes the most number of connection attempts?
         -2: Which address makes the most number of successful attempts?
         -r: What are the most common results codes and where do they come
         from?
         -F: What are the most common result codes that indicate failure (no
         auth, not found etc) and where do they come from?
         -t: Which IP number get the most bytes sent to them?
         <filename> refers to the logfile.
         "
    esac
else
echo "Please specify your command in this specified format: log_sum.sh [-n N] (-c|-2|-r|-F|-t) [-e] <filename>
-n: Limit the number of results to N
-c: Which IP address makes the most number of connection attempts?
-2: Which address makes the most number of successful attempts?
-r: What are the most common results codes and where do they come
from?
-F: What are the most common result codes that indicate failure (no
auth, not found etc) and where do they come from?
-t: Which IP number get the most bytes sent to them?
<filename> refers to the logfile.
"
fi
exit 0